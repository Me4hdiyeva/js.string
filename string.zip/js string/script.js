function getText(){
    let inp = document.getElementById('inp')
    let newtext= inp.value.toUpperCase();
    console.log(newtext);
}




let text = 'salam js';
console.log(text.length);
console.log();

// if(let i = 0; i< 100; i++);


// let text = 'salam js';
// console.log(text.toUpperCase(0));

// console.log(text[2]);

// function getText(){
//     let inp = document.getElementById('inp')
//     for(let i = 0; i< text.length; i++)
//         console.log();
    
// }


 

// let text 

