function change(){
    let pass = document.getElementById('pass');
    let btn = document.getElementById('btn')

    if( pass.type === 'password'){
        pass.type = 'text' ;
        btn.textContent = 'Hide';

    } else
    pass.type = 'password' ;
    btn.textContent = 'show';

}

let pass = document.getElementById('pass');
if( pass= 1234567){
    answer = 'pass duzdur';
} 
else{
answer = 'pass yanlisdir';
}
alert(answer)
