function Table(){
    let val = document.getElementById(select).value ;


let data = '';
for(let i = 0; i<4; i++){
    data+= '<tr>';
    
    for(let j = 0; i<4; j++){
        data+= '<td></td>';
    }
     
    data += '</tr>';
}
}
document.getElementById(table).innerHTML = data



function Table(){
    let val = document.getElementById(select).value 
    let color ='';
    let data ="";
    for(let i = 0; i<val; i++){
        data+= `<tr>`;
        for (let j = 0; j< val; j++){
            color = (i == j) ||(i+j == val - 1) ? 'black' : 'white'
             data += `<td style='background-color:${color}'>${i}-${j}</td>`
      }
        data += `<tr/>`
    }


    
    console.log(test);
}

